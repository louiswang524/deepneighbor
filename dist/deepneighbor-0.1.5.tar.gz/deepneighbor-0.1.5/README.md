# DeepNeighbor

DeepNeighbor is a **Easy-to-use**,**Modular** and **Extendible** package of deep-learning based models along with lots of core components layers which can be used to easily build custom models.You can use any complex model with `model.fit()`，and `model.predict()` .
