from .deepwalk import DeepWalk
from .embed import Embed
__all__ = ["DeepWalk","Embed"]
